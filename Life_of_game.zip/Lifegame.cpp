#include"Lifegame.h"

Lifegame::Lifegame(int s)
{
	mapSize = s;

	lifeMap.resize(mapSize);							// �����еĴ�С
	next.resize(mapSize);
	for (int i = 0; i < mapSize; i++)
	{
		lifeMap.at(i).resize(mapSize);					// �����еĴ�С
		next.at(i).resize(mapSize);

		for (int j = 0; j < mapSize; j++)
		{
														// ���ȡ0 or 1   ������PROBABILITY����
			lifeMap.at(i).at(j) = rand() % (PROBABILITY + 1) / PROBABILITY;		
			next.at(i).at(j) = lifeMap.at(i).at(j);
		}
	}
}

int Lifegame::scores(int s,int y,int x)const noexcept
{
	if (y < 0 || x < 0 || y >= mapSize || x >= mapSize)
		return 0;

	return s;
}

void Lifegame::life()
{
	int nums = 0;										// ��Χϸ������

	for (int i = 0; i < mapSize; i++)
	{
		for (int j = 0; j < mapSize; j++)
		{
			// ������Χϸ������
			nums = scores(lifeMap.at(i - 1 >= 0 ? i - 1 : 0).at(j - 1 >= 0 ? j - 1 : 0), i - 1, j - 1) +
				scores(lifeMap.at(i - 1 >= 0 ? i - 1 : 0).at(j), i - 1, j) +
				scores(lifeMap.at(i - 1 >= 0 ? i - 1 : 0).at(j + 1 < mapSize ? j + 1 : j), i - 1, j + 1) +

				scores(lifeMap.at(i).at(j - 1 >= 0 ? j - 1 : 0), i, j - 1) +
				scores(lifeMap.at(i).at(j + 1 < mapSize ? j + 1 : j), i, j + 1) +

				scores(lifeMap.at(i + 1 < mapSize ? i + 1 : i).at(j - 1 >= 0 ? j - 1 : 0), i + 1, j - 1) +
				scores(lifeMap.at(i + 1 < mapSize ? i + 1 : i).at(j), i + 1, j) +
				scores(lifeMap.at(i + 1 < mapSize ? i + 1 : i).at(j + 1 < mapSize ? j + 1 : j), i + 1, j + 1);

			if (nums == 2)
				next.at(i).at(j) = lifeMap.at(i).at(j);		// ״̬����
			else if (nums == 3)
				next.at(i).at(j) = 1;						// Ϊ��
			else
				next.at(i).at(j) = 0;						// Ϊ��
		}
	}
}

void Lifegame::draw()
{
	for (int i = 0; i < mapSize; i++)
	{
		for (int j = 0; j < mapSize; j++)
		{
			if (lifeMap.at(i).at(j))										// ��ǰ״̬�Ƿ���
																			// ���߳�ΪWDITH�ľ���
				solidrectangle(i * WIDTH, j * WIDTH, i * WIDTH + WIDTH - 1, j * WIDTH + WIDTH - 1);	

			lifeMap.at(i).at(j) = next.at(i).at(j);							// ����״̬
		}
	}
}