#include"LifeGame.h"

int main()
{
	srand(time(nullptr) & 0xffffffff);
	initgraph(NUMS * WIDTH , NUMS * WIDTH);
	Lifegame game(NUMS);

	MOUSEMSG m = GetMouseMsg();
	BeginBatchDraw();

	while (true)
	{
		if (MouseHit())
		{
			m = GetMouseMsg();
			if (m.mkRButton)
				break;
		}

		setfillcolor(BLACK);
		cleardevice();
		setfillcolor(WHITE);

		game.life();
		game.draw();
		
		FlushBatchDraw();
		Sleep(TIME);
	}

	EndBatchDraw();
	closegraph();
	return 0;
}